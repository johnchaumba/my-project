<?php

namespace app;

class Email {
    public function __construct()
    {
        echo "Email class";
    }
}