<footer>
    Copyright &copy; <?php echo $companyName ?>
</footer>
</body>
</html>

