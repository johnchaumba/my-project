<?php
// We need to have here require not include
require_once 'math.php';

echo add(4, 5).'<br>';
echo subtract(9, 4);
