<?php
// Single line comment

# Another single line comment

/*
Multiline comment
with some
long text
*/
